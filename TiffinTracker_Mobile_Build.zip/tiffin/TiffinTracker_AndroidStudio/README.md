# Tiffin Tracker — Android Studio Project

यह एक standalone Android app project है। इसमें Google Sheet या किसी server की जरूरत नहीं है।

## Features
- आज की तारीख अपने-आप
- YES = Tiffin आया
- NO = Tiffin नहीं आया
- Data phone में localStorage के जरिए save होता है
- Monthly fee default ₹1800
- महीने के दिनों के हिसाब से daily rate
- Monthly calendar और payable amount
- Previous/next month

## APK बनाने के steps
1. Android Studio खोलें.
2. **Open** दबाकर यह पूरा `TiffinTracker_AndroidStudio` folder चुनें.
3. Gradle sync पूरा होने दें. Android Studio जरूरत के build tools/plugins download कर सकता है.
4. **Build > Build APK(s)** चुनें.
5. APK `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा.

यह source project है; इस environment में Android SDK/build tools उपलब्ध न होने के कारण यहाँ से compiled APK नहीं बनाया गया है.
